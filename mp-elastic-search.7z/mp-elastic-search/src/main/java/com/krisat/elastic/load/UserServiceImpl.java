package com.krisat.elastic.load;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.krisat.common.JsonResponseUtil;
import com.krisat.elastic.model.Users;
import com.krisat.elastic.repository.ElasticUsersRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Inject
	private ElasticUsersRepository elasticUsersRepository;

	public com.krisat.common.JsonResponse registerUsersInElasticSearch(Users userRequest) {
		List<Users> users = new ArrayList<>();
		String firstname = userRequest.getFirstName();
		String lastName = userRequest.getLastName();
		Long userId = userRequest.getId();
		// String roleId=userRequest.getRoleId();
		users.add(new Users(userId, firstname, lastName, "testModule", ""));
		return JsonResponseUtil.createResponse(elasticUsersRepository.save(users));
	}

}
