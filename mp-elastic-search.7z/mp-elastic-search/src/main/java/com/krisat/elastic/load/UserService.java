package com.krisat.elastic.load;

import com.krisat.common.JsonResponse;
import com.krisat.elastic.model.Users;

public interface UserService {
	JsonResponse registerUsersInElasticSearch(Users users);
}
