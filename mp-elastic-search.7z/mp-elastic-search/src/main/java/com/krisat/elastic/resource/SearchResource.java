package com.krisat.elastic.resource;

import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.common.inject.Inject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.krisat.common.JsonResponse;
import com.krisat.common.JsonResponseUtil;
import com.krisat.elastic.load.UserService;
import com.krisat.elastic.model.Users;
import com.krisat.elastic.repository.ElasticUsersRepository;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("rest/users/search")
public class SearchResource {

	@Autowired
	ElasticUsersRepository usersRepository;

	@GetMapping(value = "/name/{name}")
	public List<Users> searchName(@PathVariable final String name) {
		List<Users> firstNameList=usersRepository.findByFirstName(name);
		List<Users> lastNameList=usersRepository.findByLastName(name);
		 return(firstNameList!=null&&firstNameList.size()>0?firstNameList:(lastNameList!=null&&lastNameList.size()>0?lastNameList:null));
	}
	

	@GetMapping(value = "/firstname/{firstname}")
	public List<Users> searchFirstName(@PathVariable final String firstname) {
		return usersRepository.findByFirstName(firstname);
	}

	@GetMapping(value = "/lastname/{text}")
	public List<Users> searchLastName(@PathVariable final String lastname) {
		return usersRepository.findByLastName(lastname);
	}

	@GetMapping(value = "/all")
	public List<Users> searchAll() {
		List<Users> usersList = new ArrayList<>();
		Iterable<Users> userses = usersRepository.findAll();
		userses.forEach(usersList::add);
		return usersList;
	}
	
	
	
	@RequestMapping(value = "/register/user", method = RequestMethod.POST,
	consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
	public JsonResponse registerUser(@RequestBody(required=true)Users userRequest ) {
		
		List<Users> users = new ArrayList<>();
		String firstname = userRequest.getFirstName();
		String lastName = userRequest.getLastName();
		Long userId = userRequest.getId();
		// String roleId=userRequest.getRoleId();
		users.add(new Users(userId, firstname, lastName, "testModule", ""));
		return JsonResponseUtil.createResponse(usersRepository.save(users));
	}

}
