package com.krisat.elastic.load;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.krisat.elastic.model.Users;
import com.krisat.elastic.repository.ElasticUsersRepository;

@Component
public class Loaders {

    @Autowired
    ElasticsearchOperations operations;

    @Autowired
    ElasticUsersRepository usersRepository;

    @PostConstruct
    @Transactional
    public void loadAll(){

        operations.putMapping(Users.class);
        System.out.println("Loading Data");
        usersRepository.save(getData());
        System.out.printf("Loading Completed");

    }

    private List<Users> getData() {
        List<Users> userses = new ArrayList<>();
        userses.add(new Users(123L,"Ajay","sss","course", "gdgfdgf"));
        userses.add(new Users(124L,"Ram","rrr","course", "gdgfdgf"));
        userses.add(new Users(125L,"Krishna","TTT","course", "gdgfdgf"));
        userses.add(new Users(126L,"Seenu","SS","course", "gdgfdgf"));
        userses.add(new Users(127L,"Charu","SS","course", "gdgfdgf"));
        userses.add(new Users(128L,"Hari","GG","course", "gdgfdgf"));
        userses.add(new Users(129L,"Kanwal","RRR","course", "gdgfdgf"));
        userses.add(new Users(130L,"Rishi","FFF","course", "gdgfdgf"));

        return userses;
    }
}
