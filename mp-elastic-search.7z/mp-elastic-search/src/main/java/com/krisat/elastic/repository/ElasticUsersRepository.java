package com.krisat.elastic.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.krisat.elastic.model.Users;

import java.util.List;

public interface ElasticUsersRepository extends ElasticsearchRepository<Users, Long> {
    List<Users> findByFirstName(String name);
    List<Users> findByLastName(String name);


}
