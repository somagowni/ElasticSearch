# Spring Data Elastic Search
This project depicts the Elastic Search functionality with Spring Data Elastic Search.

## Description
This Project loads the list of Users into Elastic and Searches. 
Using the following endpoints, different operations can be achieved:
-/rest/users/search/register/user - For registering users
- `/rest/search/first/{firstname}` - This returns the list of Users for a firstName.
- `/rest/search/last/{lastname}` - This returns the list of Users for lastName.
- `/rest/users/search/all` - This returns all Users.

## Libraries used
- Spring Boot
- Spring REST Controller
- Spring Data Elastic Search

## Git 2.10.0
- IntelliJ IDEA 2016.2.4

## Compilation Command
- `mvn clean install` - Plain maven clean and install

Run below command  for respective environment
java -jar /target/mp-elastic-search-0.0.1-SNAPSHOT.jar
